<?php
echo "Hospital Chatbot Backend is running.";
?>
